import HeroSection from "../HeroSection";

import React from 'react'
import MySkills from "../Skills";

export default function Index() {
  return (
    <>
        <HeroSection/>
        <MySkills/>
    </>
  )
}
